export class Comment {



    // user_id
    // product_id
    // comment
    // stars 
    // created_at 

}
