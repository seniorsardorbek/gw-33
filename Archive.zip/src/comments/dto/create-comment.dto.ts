export class CreateCommentDto {}
